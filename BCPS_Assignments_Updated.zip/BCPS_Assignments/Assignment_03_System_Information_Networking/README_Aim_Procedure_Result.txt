BCPS ASSIGNMENT: Lab 03: System Information and Networking Commands

AIM
Learn basic system and networking commands.

PROCEDURE
1. Run system-information commands.
2. Check the hostname and current user.
3. Inspect network configuration.
4. Test loopback connectivity and DNS lookup.

RESULT
The purpose and use of common system and networking commands were recorded.

FILES IN THIS FOLDER
- System_Information_and_Networking.docx

Note: These are completed sample assignments prepared from the topic list in your screenshot. If your teacher's README contains exact questions, compare these with that brief and adjust any required names/data before submission.
