BCPS ASSIGNMENT: Lab 05: Personalized Invitations Using Writer Mail Merge

AIM
Prepare a reusable invitation and personalize it for recipients.

PROCEDURE
1. Open the invitation template.
2. Use Recipients.csv as the data source.
3. Insert recipient fields using Mail Merge Wizard.
4. Preview the records and finish the merge.

RESULT
A personalized invitation template and recipient list were created.

FILES IN THIS FOLDER
- Invitation_Template_and_Mail_Merge_Guide.docx
- Recipients.csv

Note: These are completed sample assignments prepared from the topic list in your screenshot. If your teacher's README contains exact questions, compare these with that brief and adjust any required names/data before submission.
