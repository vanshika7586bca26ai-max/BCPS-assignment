BCPS ASSIGNMENT: Lab 07: Calc Attendance

AIM
Calculate attendance percentage and status.

PROCEDURE
1. Enter attendance counts.
2. Calculate percentage attended.
3. Compare attendance against 75%.

RESULT
The register calculates attendance and indicates the threshold status.

FILES IN THIS FOLDER
- Attendance_Register.xlsx
- Attendance_Formula_Guide.docx

Note: These are completed sample assignments prepared from the topic list in your screenshot. If your teacher's README contains exact questions, compare these with that brief and adjust any required names/data before submission.
