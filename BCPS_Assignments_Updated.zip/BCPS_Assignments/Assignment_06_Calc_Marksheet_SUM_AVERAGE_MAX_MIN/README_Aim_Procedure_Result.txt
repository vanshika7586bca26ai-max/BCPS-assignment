BCPS ASSIGNMENT: Lab 06: Calc Marksheet

AIM
Use Calc functions to analyze marks.

PROCEDURE
1. Open the spreadsheet.
2. Inspect formulas in the calculated columns.
3. Change a mark and verify that totals and averages update.

RESULT
The marksheet demonstrates SUM, AVERAGE, MAX and MIN.

FILES IN THIS FOLDER
- Student_Marksheet.xlsx
- Marksheet_Formula_Guide.docx

Note: These are completed sample assignments prepared from the topic list in your screenshot. If your teacher's README contains exact questions, compare these with that brief and adjust any required names/data before submission.
