BCPS ASSIGNMENT: Lab 08: Calc Salary and Inventory

AIM
Create salary and inventory sheets using formulas.

PROCEDURE
1. Calculate net salary for employees.
2. Calculate grand total salary.
3. Calculate closing stock and stock value.
4. Calculate the total stock value.

RESULT
Both spreadsheets demonstrate formulas for salary and inventory management.

FILES IN THIS FOLDER
- Salary_Register.xlsx
- Inventory_Register.xlsx
- Salary_and_Inventory_Guide.docx

Note: These are completed sample assignments prepared from the topic list in your screenshot. If your teacher's README contains exact questions, compare these with that brief and adjust any required names/data before submission.
