BCPS ASSIGNMENT: Lab 01–02: Command-Line File Management

AIM
Practice basic file and folder operations from the terminal.

PROCEDURE
1. Create a practice folder.
2. Create and display a text file.
3. Copy, rename and move a file.
4. List folder contents and clean up the practice folder.

RESULT
The command-line file-management operations were demonstrated.

FILES IN THIS FOLDER
- Command_Line_File_Management.docx

Note: These are completed sample assignments prepared from the topic list in your screenshot. If your teacher's README contains exact questions, compare these with that brief and adjust any required names/data before submission.
