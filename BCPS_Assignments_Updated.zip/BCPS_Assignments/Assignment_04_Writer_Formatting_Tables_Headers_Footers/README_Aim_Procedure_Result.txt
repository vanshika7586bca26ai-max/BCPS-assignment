BCPS ASSIGNMENT: Lab 04: Writer Formatting, Tables, Headers, Footers and Page Numbers

AIM
Format a document using headings, a table, a header and a footer.

PROCEDURE
1. Open the document in LibreOffice Writer.
2. Review the heading hierarchy and table.
3. Use Insert > Page Number to add automatic page numbering if required.
4. Save a final copy in ODT format if your teacher requires native LibreOffice format.

RESULT
A formatted document with headings, a table, header and footer was prepared.

FILES IN THIS FOLDER
- Writer_Formatting_Practical.docx

Note: These are completed sample assignments prepared from the topic list in your screenshot. If your teacher's README contains exact questions, compare these with that brief and adjust any required names/data before submission.
